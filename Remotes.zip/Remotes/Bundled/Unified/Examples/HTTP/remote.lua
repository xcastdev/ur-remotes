-- https://github.com/unifiedremote/Docs/blob/master/libs/http.md
local http = libs.http;

--@help Command 1
actions.something = function ()
	http.get("http://127.0.0.1:9510/system/status", function (err, resp) 
		print(err);
		print(resp);
	end);
end