local http = libs.http;
local timer = libs.timer;
local data = libs.data;
local utf8 = libs.utf8;
local server = require("server");

local tids = nil;
local tidl = nil;

local update_status;
local update_log;
local command = "";

-- Convert a value to displayable text without throwing an error.
local safe_text = function(value, fallback)
	if value == nil then
		return fallback or "(missing)";
	end

	return tostring(value);
end

-- Make an internal Unified Remote HTTP request safely.
--
-- Returns:
--   response, nil       on success
--   nil, error_message  on failure
local ur = function(path)
	local ok, response = pcall(function()
		return  http.get("http://127.0.0.1:9510/" .. path);
	end);

	if not ok then
		return nil, "HTTP exception: " .. safe_text(response, "unknown error");
	end

	if response == nil then
		return nil, "HTTP request returned nil";
	end

	if response == "" then
		return nil, "HTTP request returned an empty response";
	end

	return response, nil;
end

-- Request and decode a JSON endpoint safely.
--
-- Returns:
--   decoded, nil        on success
--   nil, error_message  on failure
local ur_json = function(path)
	local response, request_error = ur(path);

	if response == nil then
		return nil, request_error;
	end

	local ok, decoded = pcall(function()
		return data.fromjson(response);
	end);

	if not ok then
		local preview = tostring(response);

		if #preview > 500 then
			preview = string.sub(preview, 1, 500) .. "...";
		end

		return nil,
			"Invalid JSON from /" ..
			path ..
			": " ..
			safe_text(decoded, "unknown JSON error") ..
			"\n\nResponse:\n" ..
			preview;
	end

	if decoded == nil then
		return nil, "JSON decoder returned nil for /" .. path;
	end

	return decoded, nil;
end

local cancel_timers = function()
	if tids ~= nil then
		pcall(function()
			timer.cancel(tids);
		end);

		tids = nil;
	end

	if tidl ~= nil then
		pcall(function()
			timer.cancel(tidl);
		end);

		tidl = nil;
	end
end

--@help Restart manager
actions.restart = function()
	local _, request_error = ur("system/restart");

	if request_error ~= nil then
		layout.command.text = "Restart failed:\n" .. request_error;
	else
		layout.command.text = "Restart requested.";
	end
end

--@help Reload remote
actions.reload = function()
	local _, request_error = ur("system/reload");

	if request_error ~= nil then
		layout.command.text = "Reload failed:\n" .. request_error;
	else
		layout.command.text = "Reload requested.";
	end
end

--@help Open server manager
actions.open = function()
	os.open("http://localhost:9510/web");
end

events.focus = function()
	-- Avoid accumulating multiple intervals if focus fires repeatedly.
	cancel_timers();

	timer.timeout(function()
		local ok, callback_error = pcall(update_status);

		if not ok then
			layout.misc.text =
				"update_status exception:\n" ..
				safe_text(callback_error, "unknown error");
		end
	end, 100);

	tids = timer.interval(function()
		local ok, callback_error = pcall(update_status);

		if not ok then
			layout.misc.text =
				"update_status exception:\n" ..
				safe_text(callback_error, "unknown error");
		end
	end, 2000);

	tidl = timer.interval(function()
		local ok, callback_error = pcall(update_log);

		if not ok then
			layout.log.text =
				"update_log exception:\n" ..
				safe_text(callback_error, "unknown error");
		end
	end, 700);
end

events.blur = function()
	cancel_timers();
end

update_status = function()
	local status, status_error = ur_json("system/status");

	if status == nil then
		layout.misc.text =
			"Unable to load server status:\n" ..
			safe_text(status_error, "unknown error");

		layout.intf.text = "Interface data unavailable.";
		layout.network.text = "Network data unavailable.";
		return;
	end

	----------------------------------------------------------------
	-- General server information
	----------------------------------------------------------------

	local machine = safe_text(status["machine"]);
	local operating_system = safe_text(status["os"]);
	local version = safe_text(status["version"]);
	local version_code = safe_text(status["version-code"]);
	local started = safe_text(status["started"]);

	local misc = "";

	misc = misc .. machine .. " (" .. operating_system .. ")\n";
	misc = misc .. "UR Version: " .. version .. " (" .. version_code .. ")\n";
	misc = misc .. "Running since " .. started .. "\n";

	layout.misc.text = utf8.trim(misc);

	----------------------------------------------------------------
	-- Interface information
	----------------------------------------------------------------

	local interfaces = status["interfaces"] or {};
	local discovery = interfaces["ad"] or {};
	local bluetooth = interfaces["bt"] or {};
	local wireless = interfaces["wifi"] or {};

	local intf = "Discovery: ";

	if discovery["status"] ~= nil and discovery["status"] ~= false then
		intf = intf .. safe_text(discovery["status"]) .. "\n";
	else
		intf = intf .. safe_text(discovery["error"], "(unavailable)") .. "\n";
	end

	intf = intf .. "Bluetooth: ";

	if bluetooth["status"] ~= nil and bluetooth["status"] ~= false then
		intf = intf .. safe_text(bluetooth["status"]) .. "\n";
	else
		intf = intf .. safe_text(bluetooth["error"], "(unavailable)") .. "\n";
	end

	intf = intf .. "Wireless: ";

	if wireless["status"] ~= nil and wireless["status"] ~= false then
		intf = intf .. safe_text(wireless["status"]) .. "\n";
	else
		intf = intf .. safe_text(wireless["error"], "(unavailable)") .. "\n";
	end

	layout.intf.text = utf8.trim(intf);

	----------------------------------------------------------------
	-- Network information
	----------------------------------------------------------------

	local network = status["network"] or {};
	local lan = network["lan"] or {};
	local wan = network["wan"] or {};

	local network_text = "LAN: ";

	if lan["available"] then
		network_text =
			network_text ..
			safe_text(lan["address"], "(address missing)") ..
			"\n";
	else
		network_text = network_text .. "(unavailable)\n";
	end

	network_text = network_text .. "WAN: ";

	if wan["available"] then
		network_text =
			network_text ..
			safe_text(wan["address"], "(address missing)") ..
			"\n";
	else
		network_text = network_text .. "(unavailable)\n";
	end

	layout.network.text = utf8.trim(network_text);
end

update_log = function()
	local log_response, log_error = ur_json("system/log/6/6");

	if log_response == nil then
		layout.log.text =
			"Unable to load server log:\n" ..
			safe_text(log_error, "unknown error");
		return;
	end

	local log_data = log_response["data"];

	if type(log_data) ~= "table" then
		layout.log.text =
			"Invalid server log response:\n" ..
			'Expected a table in the "data" field.';
		return;
	end

	local lines = {};

	for i = 1, #log_data do
		local raw_line = safe_text(log_data[i], "");
		local formatted_line = {" ------ "};
		local split = utf8.split(raw_line, " ");

		for ii = 1, #split do
			if ii <= 3 and ii ~= 3 then
				table.insert(formatted_line, split[ii]);
			end

			if ii == 3 then
				table.insert(formatted_line, split[ii] .. " ------\n");
			end

			if ii >= 4 then
				table.insert(formatted_line, split[ii]);
			end
		end

		table.insert(lines, utf8.join(" ", formatted_line));
	end

	if #lines == 0 then
		layout.log.text = "(No log entries returned)";
	else
		layout.log.text = utf8.join("\n", lines);
	end
end

actions.edit = function(c)
	command = c or "";
end

--@help Send action
actions.execute = function()
	local c = utf8.trim(command or "");

	if c ~= nil and c ~= "" then
		layout.command.text = "...sending...";

		local _, request_error = ur("system/remote/run/" .. c);

		if request_error ~= nil then
			layout.command.text =
				"...sending failed...\n" ..
				request_error;
		else
			layout.command.text = "...sending...success!";
		end
	else
		layout.command.text = "...invalid command...";
	end

	timer.timeout(function()
		layout.command.text = c or "";
	end, 1000);
end